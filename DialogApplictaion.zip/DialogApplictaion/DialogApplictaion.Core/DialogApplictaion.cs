﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialogApplictaion.Core
{
    public class DialogApplictaion : IDialogApplictaion
    {
        public async Task<int> Calculate(string expression, string path = "")
        {
            int result = 0;

            string[] expressions = expression.Split('+');

            if (expressions.Length > 1)
            {
                result = 0;
                foreach (string expr in expressions)
                    result += await Calculate(expr);
                return result;
            }

            expressions = expression.Split('-');

            if (expressions.Length > 1)
            {
                result = await Calculate(expressions[0]);
                for (int i = 1; i < expressions.Length; i++)
                    result -= await Calculate(expressions[i]);
                return result;
            }

            expressions = expression.Split('*');

            if (expressions.Length > 1)
            {
                result = 1;
                foreach (string expr in expressions)
                    result *=  await Calculate(expr);
                return result;
            }

            expressions = expression.Split('/');

            if (expressions.Length > 1)
            {
                result = await Calculate(expressions[0]);
                for (int i = 1; i < expressions.Length; i++)
                    result /= await Calculate(expressions[i]);
                return result;
            }

            if (!int.TryParse(expression, out result))
                throw new ArgumentException("Expression was not nummeric", "expression");

            // this.WriteToOutputFile(result.ToString(), path);

            return result;
        }

        //private void WriteToOutputFile(string line,string path)
        //{
        //    using (System.IO.StreamWriter file = new System.IO.StreamWriter($@"{path}\Output.txt"))
        //    {
        //        file.WriteLine(line);
        //    }
        //}

        public async Task<int> ReadLinesAndCalculate(string path)
        {
            string[] lines = System.IO.File.ReadAllLines($@"{path}");

            foreach (string line in lines)
            {
                string[] lineParameters = line.Split(',');

                if (lineParameters.Count() == 2)
                {
                    var param1 = lineParameters[0];

                    int sleepTime = 0;

                    bool ifSuccess = int.TryParse(lineParameters[1], out sleepTime);

                    if (ifSuccess)
                    {
                        await Task.Delay(sleepTime);
                        await Calculate(param1).ConfigureAwait(false);
                    }
                }
               
            }

            return 0;
        }
       
    }
}
