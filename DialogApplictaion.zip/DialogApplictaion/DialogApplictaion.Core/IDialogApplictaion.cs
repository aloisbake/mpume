﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DialogApplictaion.Core
{
    public interface IDialogApplictaion
    {
        Task<int> Calculate(string expression, string path = "");
        Task<int> ReadLinesAndCalculate(string path);
    }
}
